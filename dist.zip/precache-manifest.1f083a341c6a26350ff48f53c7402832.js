self.__precacheManifest = [
  {
    "revision": "c275e5189ecaabdbfdc5407dc031c28b",
    "url": "/img/baseline-menu-24px.c275e518.svg"
  },
  {
    "revision": "e5bfa9dd1f8eaf7abdf1e3f066aff673",
    "url": "/service-worker.js"
  },
  {
    "revision": "ff1dee6e028cdc8df82a4c72d66f19e7",
    "url": "/img/outline-info-24px.ff1dee6e.svg"
  },
  {
    "revision": "61a92883c99746653149",
    "url": "/js/app.38ca0ebd.js"
  },
  {
    "revision": "33858b00bb07acb932d2",
    "url": "/js/chunk-vendors.533c096a.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "c6c11f243a1b4a8ad46c",
    "url": "/js/chunk-2d0b59a6.322f87d6.js"
  },
  {
    "revision": "941b8a1b8d40cab709d7",
    "url": "/js/about.2cb58bd9.js"
  },
  {
    "revision": "f19cfbc387ead5e360d3e333b1c8aaae",
    "url": "/index.html"
  },
  {
    "revision": "e530cabeed6af444668bece65129a26e",
    "url": "/img/outline-store_mall_directory-24px.e530cabe.svg"
  },
  {
    "revision": "23ea88a18d86fcd079655056a1859afb",
    "url": "/img/outline-list-24px.23ea88a1.svg"
  },
  {
    "revision": "82b9c7a5a3f405032b1db71a25f67021",
    "url": "/img/logo.82b9c7a5.png"
  },
  {
    "revision": "c915103363017d14cea9c2a46ea12166",
    "url": "/img/apple-touch-icon.c9151033.png"
  },
  {
    "revision": "61a92883c99746653149",
    "url": "/css/app.a4c199c0.css"
  }
];